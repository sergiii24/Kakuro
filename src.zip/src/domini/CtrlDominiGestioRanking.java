package domini;

public class CtrlDominiGestioRanking {
}
