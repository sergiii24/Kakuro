package domini;

import java.io.Serializable;

public enum TipusMode implements Serializable  {
    CONTRARRELLOTGE, NORMAL, TRAINING
}
