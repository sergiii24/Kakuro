package domini;

import java.io.Serializable;

public enum TipusDificultat implements Serializable {
	FACIL, NORMAL, DIFICIL
}
