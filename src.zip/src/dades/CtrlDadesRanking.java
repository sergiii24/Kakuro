package dades;

public class CtrlDadesRanking {
}
